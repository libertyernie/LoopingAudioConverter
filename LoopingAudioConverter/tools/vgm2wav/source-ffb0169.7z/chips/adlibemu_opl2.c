#include "mamedef.h"

#define OPLTYPE_IS_OPL2
#include "adlibemu.h"
#include "opl.c"
