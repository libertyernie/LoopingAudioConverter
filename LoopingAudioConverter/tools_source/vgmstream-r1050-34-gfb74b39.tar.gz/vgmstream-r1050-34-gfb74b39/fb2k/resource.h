//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by foo_input_vgmstream.rc
//

#define IDD_CONFIG                      101
#define IDC_LOOP_COUNT                  1000
#define IDC_FADE_SECONDS                1001
#define IDC_FADE_DELAY_SECONDS          1002
#define IDC_LOOP_NORMALLY               1003
#define IDC_LOOP_FOREVER                1004
#define IDC_IGNORE_LOOP                 1005
#define IDC_THREAD_PRIORITY_SLIDER      1006
#define IDC_THREAD_PRIORITY_TEXT        1007
#define IDC_DEFAULT_BUTTON              1008

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
